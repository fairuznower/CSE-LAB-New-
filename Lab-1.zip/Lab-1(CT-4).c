#include<stdio.h>
int main()
{
 int var;
 scanf("%d", &var);
 printf("%d", var);
 return 0;
}