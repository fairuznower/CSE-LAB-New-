#include<stdio.h>
int main()
{
 float var;
 var=3.5;
 printf("%f", var);
 return 0;
}