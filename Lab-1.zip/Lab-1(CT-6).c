#include<stdio.h>
int main()
{
 float var;
 scanf("%f", &var);
 printf("%f", var);
 return 0;
}
