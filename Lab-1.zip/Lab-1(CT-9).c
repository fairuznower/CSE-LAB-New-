#include<stdio.h>
int main()
{
 int var1;
 float var2;
 char ch;
 scanf("%d%f%c", &var1, &var2, &ch);
 printf("%d\n%f\n%c\n", var1, var2,ch);
 return 0;
}