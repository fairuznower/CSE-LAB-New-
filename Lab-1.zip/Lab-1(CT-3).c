#include<stdio.h>
int main()
{
 int a=2;
 printf("%d", a);
 return 0;
}