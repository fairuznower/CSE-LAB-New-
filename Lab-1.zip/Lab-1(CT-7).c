#include <stdio.h>
int main ()
{
 char ch = 'c';
 printf("Character is:%c\n", ch);
 return 0;
}
