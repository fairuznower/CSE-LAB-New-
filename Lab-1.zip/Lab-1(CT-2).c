#include<stdio.h>
int main()
{
 printf("Hello\n World!\n");
 return 0;
}