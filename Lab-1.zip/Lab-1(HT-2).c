#include <stdio.h>
int main()
{
printf("Name: Fairuz");
printf("Adress: Uttara");
printf("City: Uttara, Dhaka);
return 0;
