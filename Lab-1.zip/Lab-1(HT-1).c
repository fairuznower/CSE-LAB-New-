#include<stdio.h>
int main()
{
printf("Hello Computer");
 return 0;
}